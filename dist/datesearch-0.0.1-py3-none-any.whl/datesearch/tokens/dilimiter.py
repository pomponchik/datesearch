from datesearch.tokens.abstract_token import AbstractToken


class Dilimiter(AbstractToken):
    @staticmethod
    def its_me(chunk):
        pass

    def source_parse(self):
        return number

    def equal_content(self, letters):
        return False
